package com.example.nfclab


import android.app.Activity
import android.nfc.NfcAdapter
import android.nfc.Tag
import android.nfc.tech.Ndef
import android.nfc.tech.NdefFormatable
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.view.View
import android.graphics.Color

class MainActivity : Activity(), NfcAdapter.ReaderCallback {
    private var adapter: NfcAdapter? = null
    private lateinit var scanStatus: TextView
    private lateinit var profileInput: EditText
    private lateinit var profileStatus: TextView
    private val prefs by lazy { getSharedPreferences("profiles", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        adapter = NfcAdapter.getDefaultAdapter(this)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(32, 32, 32, 32) }
        root.addView(TextView(this).apply { text = "NFC Lab — диагностика и тест HCE"; textSize = 22f })
        scanStatus = TextView(this).apply { text = "Нажми «Сканировать», затем приложи NFC-метку."; textSize = 16f; setPadding(0,24,0,24) }
        root.addView(scanStatus)
        root.addView(Button(this).apply { text = "Сканировать NFC"; setOnClickListener { startReader() } })
        root.addView(Button(this).apply { text = "Остановить сканирование"; setOnClickListener { stopReader(); scanStatus.text = "Сканирование остановлено" } })
        root.addView(TextView(this).apply { text = "Демо-профиль HCE (только тестовый AID)"; textSize = 18f; setPadding(0,28,0,8) })
        profileInput = EditText(this).apply { hint = "Текст тестового профиля"; setText(prefs.getString("profile", "NFC Lab demo")) }
        root.addView(profileInput)
        root.addView(Button(this).apply { text = "Сохранить профиль"; setOnClickListener { val s=profileInput.text.toString().take(80); prefs.edit().putString("profile",s).apply(); DemoHceService.profileText=s; profileStatus.text="Сохранено. Для демонстрации использует собственный AID." } })
        profileStatus = TextView(this).apply { text = "HCE демонстрация использует отдельный тестовый AID F0010203040506, не копирует карты доступа."; setPadding(0,16,0,0) }
        root.addView(profileStatus)
        setContentView(root)
        DemoHceService.profileText = prefs.getString("profile", "NFC Lab demo") ?: "NFC Lab demo"
    }

    private fun startReader() {
        if (adapter == null) { scanStatus.text = "На этом устройстве нет NFC."; return }
        if (!adapter!!.isEnabled) { scanStatus.text = "Включи NFC в системных настройках."; return }
        val flags = NfcAdapter.FLAG_READER_NFC_A or NfcAdapter.FLAG_READER_NFC_B or NfcAdapter.FLAG_READER_NFC_F or NfcAdapter.FLAG_READER_NFC_V
        adapter!!.enableReaderMode(this, this, flags, null)
        scanStatus.text = "Ожидаю метку… UID не сохраняется."
    }
    private fun stopReader() { adapter?.disableReaderMode(this) }
    override fun onPause() { super.onPause(); stopReader() }
    override fun onTagDiscovered(tag: Tag) {
        val techs = tag.techList.map { it.substringAfterLast('.') }.distinct().joinToString(
            ", ").ifBlank { "Неизвестная технология" }
        var ndefInfo = "NDEF: не обнаружен"
        try {
            val ndef = Ndef.get(tag)
            if (ndef != null) {
                ndef.connect()
                ndefInfo = "NDEF: ${if (ndef.isWritable) "записываемый" else "только чтение"}; тип=${ndef.type}; размер=${ndef.maxSize} байт"
                ndef.close()
            }
        } catch (_: Exception) { ndefInfo = "NDEF: недоступен" }
        runOnUiThread { scanStatus.text = "Метка найдена\nТехнологии: $techs\n$ndefInfo\nUID не считывается приложением." }
    }
}

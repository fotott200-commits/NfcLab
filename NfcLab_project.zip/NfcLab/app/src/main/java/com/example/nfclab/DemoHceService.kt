package com.example.nfclab

import android.nfc.cardemulation.HostApduService
import android.os.Bundle

class DemoHceService : HostApduService() {
    companion object { @Volatile var profileText: String = "NFC Lab demo" }
    private val selectDemoAid = byteArrayOf(0x00,0xA4.toByte(),0x04,0x00,0x07,0xF0.toByte(),0x01,0x02,0x03,0x04,0x05,0x06,0x00)
    override fun processCommandApdu(commandApdu: ByteArray, extras: Bundle?): ByteArray {
        if (commandApdu.contentEquals(selectDemoAid)) return byteArrayOf(0x90.toByte(),0x00)
        // Demo-only response: GET DATA (00 CA 00 00 00) returns profile UTF-8 and 9000.
        if (commandApdu.size >= 4 && commandApdu[0] == 0x00.toByte() && commandApdu[1] == 0xCA.toByte()) {
            val payload = profileText.toByteArray(Charsets.UTF_8).take(80).toByteArray()
            return payload + byteArrayOf(0x90.toByte(),0x00)
        }
        return byteArrayOf(0x6D,0x00) // unsupported instruction
    }
    override fun onDeactivated(reason: Int) { }
}

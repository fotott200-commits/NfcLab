# NFC Lab (Android/Kotlin starter)

A small Android project for NFC technology diagnostics and a benign HCE test profile.

## Included
- Reader mode scan of NFC-A/B/F/V technologies; displays technology names and NDEF capability/size.
- Does not capture or save tag UID/serial data.
- Simple local profile text saved in SharedPreferences.
- HCE demo service using a dedicated test AID `F0010203040506`, with a small custom GET DATA response.

## Build
Open this folder in Android Studio, allow Gradle sync, then Build > Build APK(s).

HCE works only on phones with host card emulation support. This is a test profile, not an emulator for real access credentials.
